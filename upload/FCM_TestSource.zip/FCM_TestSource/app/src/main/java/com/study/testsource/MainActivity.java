package com.study.testsource;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRequestToken = (Button) findViewById(R.id.logTokenButton);
        final TextView tvTokenInfo = (TextView) findViewById(R.id.logtext);
        btnRequestToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String token = FirebaseInstanceId.getInstance().getToken();
                //파이어베이스 푸쉬 토큰값 얻어오는 명령어 FirebaseInstanceId.getInstance().getToken()

                Log.d("textLog", "토큰을 얻어오자 token : " + token);

                tvTokenInfo.setText("토큰값 : " + token);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
